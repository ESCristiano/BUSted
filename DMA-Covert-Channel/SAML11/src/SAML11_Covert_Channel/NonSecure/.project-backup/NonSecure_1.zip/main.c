/**
 * \file
 *
 * Copyright (c) 2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#include "atmel_start.h"
#include "trustzone_veneer.h"
#include "driver_examples.h"

/* Non-secure main() */
int main(void)
{
	uint32_t temp_result, clocks = 3;


	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	printf("Non-secure program is running.\r\n");

		//TIMER_0_example();
	while (1) {
		/* Get temperature from secure temp sensor driver */
		// temp_result = nsc_temperature_sensor_read();
		// printf("Temperature = %d deg C\r", (int)temp_result);
		int *ptr = 0x42001000+0x14;
		int *sync = 0x42001000 + 0x05;
		int *ptr1 = 0x42001400+0x14;
		int *ptr2 = 0x42001800+0x14;
		// printf("Count 1 = %d \r\n", *ptr);
		*sync = 0x80;
		printf("TC0 = %d \r\n", *ptr); 
		printf("TC1 = %d \r\n", *ptr1); 
		printf("TC2 = %d \r\n", *ptr2); 
		gpio_toggle_pin_level(LED0);
		delay_ms(1000);
		printf("TC0 = %d \r\n", *ptr); 
		printf("TC1 = %d \r\n", *ptr1); 
		printf("TC2 = %d \r\n\r\n", *ptr2); 
	}
}
